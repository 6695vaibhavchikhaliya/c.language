#include<stdio.h>
main(){
	
	int n,m;
	
	printf("Enter Value Of Starting Programe : ");
	scanf("%d",&n);
	printf("Enter Value Of Ending Programe : ");
	scanf("%d",&m);
	
	while(n <= m)
	{
		if(n % 2 == 0){
			printf("%d",n);
		}
		n++;
		printf("\n");
	}
}
