#include<stdio.h>
main(){
	
	int n = 1,m = 10;
	
	while(n <= m){
		printf("%d",n);
		n++;
		printf("\n");
	}
	
}
