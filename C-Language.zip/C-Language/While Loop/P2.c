#include<stdio.h>
main(){
	
	int n = 1,m = 10;
	
	while(m >= n){
		printf("%d",m);
		m--;
		printf("\n");
	}
}
