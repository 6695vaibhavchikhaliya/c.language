#include<stdio.h>
main(){
	
	int n,m;
	
	printf("Enter Of Value Starting Of Programe : ");
	scanf("%d",&n);
	printf("Enter Of Value Ending Of Programe :  ");
	scanf("%d",&m);
	
	while(n <= m){
		printf("%d",n);
		n++;
		printf("\n");		
	}
}
