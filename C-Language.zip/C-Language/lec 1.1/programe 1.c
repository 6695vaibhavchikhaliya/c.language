#include<stdio.h>

main(){
	
	printf("helo...!helo world...!");
	
}
