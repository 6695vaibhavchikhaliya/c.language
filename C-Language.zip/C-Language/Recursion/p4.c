#include<stdio.h>

void fact(int n)
{
	if(n <= 1) 
	{
		return 1;
	}
	else{
		return * fact(n - 1);
	}
}

void main()
{
	fact(5)
}
