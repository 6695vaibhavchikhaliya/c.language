#include<stdio.h>

void loop(int start,int end)
{
	if(start <= end)
	{
		printf("%d \t",end--);
		loop(start,end);
	}
}

void main()
{
	loop(1,10);
}
