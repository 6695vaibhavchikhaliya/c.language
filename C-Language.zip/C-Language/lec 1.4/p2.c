#include<stdio.h>
main(){
	
	int a = 10,b = 5,c;
	c=(float)a+b;
	printf("%f",(float)c);		
	
}
