#include<stdio.h>

main(){
	
	int a=1.5,b=5.2,c;
	c=(int)a+b;
	
	printf("%d",(int)c);
	
}
