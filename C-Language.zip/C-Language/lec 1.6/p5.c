#include<stdio.h>

main(){
	
	int age;
	
	printf("Please Enter Your A Age : \n");
	scanf("%d",&age);
	
	if(age <= 12){
		printf("You Are Younger \n");
	}else if(age >=13 && age <= 19){
		printf("You Are Teenager \n");
	}else if(age >= 20 && age <= 70){
		printf("You Are Adult \n");
	}else{
		printf("You Are A Senior Citizen \n");
	}
}
