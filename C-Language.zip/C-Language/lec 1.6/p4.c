#include<stdio.h>

main(){
	
	int a;
	
	printf("Enter Your Age : \n");
	scanf("%d",&a);
	
	if(a <= 0){
		printf("Please Enter Your Vaild Age");
	}	
	else if(a >= 18){
		printf("You Are Eligable For Vote");
	}
	else{
		printf("You Are Not Eligable For Vote");
	}
}
