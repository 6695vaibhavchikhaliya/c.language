#include<stdio.h>

main(){
	
	int a;
	
	printf("Enter Your Number For A Cheak : \n");
	scanf("%d",&a);
	
	if(a % 2 == 0){
		printf("Your Value Is Even");
	}
	else{
		printf("your Value Is Odd");
	}
	
}
