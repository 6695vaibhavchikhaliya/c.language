#include<stdio.h>
main(){
	char alphabet = 'a';
	
	do{
		printf("%c",alphabet);
		
		alphabet += 4;
	}while (alphabet <= 'z' && alphabet >= 'a');
	printf("\n");
}
