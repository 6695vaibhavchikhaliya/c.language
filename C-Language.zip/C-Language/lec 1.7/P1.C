#include<stdio.h>
main(){
	
	
	int a,b,c,d,e,f,g,h;
	
	
	printf("enter no of a: ");
	scanf("%d",&a);
	
	printf("enter no of b: \n");
	scanf("%d",&b);
	
	printf("enter no of c: \n");
	scanf("%d",&c);
	
	printf("enter no of d: \n");
	scanf("%d",&d);
	
	printf("enter no of e: \n");
	scanf("%d",&e);
	
	printf("enter no of f: \n");
	scanf("%d",&f);
	
	printf("enter no of g: \n");
	scanf("%d",&g);
	
	printf("enter no of h: \n");
	scanf("%d",&h);
	
	
	
	if(a>b){
		if(a>c){
			if(a>d){
				if(a>e){
					if(a>f){
						if(a>g){
							if(a>h){
								printf("a is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
						
					}
					else{
						
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
						
					}
					
				}
				
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					
				}
			}
			
			else{
				if(d>e){
					if(d>f){
						if(d>g){
							if(d>h){
								printf("d is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
				
			}
		}
		
		else{
			if(c>d){
				if(c>e){
					if(c>f){
						if(c>g){
							if(c>h){
								printf("c is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
						
					}
				}
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
			}
			else{
				if(d>e){
					if(d>f){
						if(d>g){
							if(d>h){
								printf("d is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
			}
			
		}
		
	}
	
	
	
	else{
		if(b>c){
			if(b>d){
				if(b>e){
					if(b>f){
						if(b>g){
							if(b>h){
								printf("b is big");
							}
							else{
								printf("h is big");
							}
						}
						else{
								if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
			}
			else{
						if(d>e){
					if(d>f){
						if(d>g){
							if(d>h){
								printf("d is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
			}
		}
		else{
						if(c>d){
				if(c>e){
					if(c>f){
						if(c>g){
							if(c>h){
								printf("c is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
						
					}
				}
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
			}
			else{
				if(d>e){
					if(d>f){
						if(d>g){
							if(d>h){
								printf("d is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
				else{
					if(e>f){
						if(e>g){
							if(e>h){
								printf("e is max");
							}
							else{
								printf("h is max");
							}
							
							}
							else{
								if(g>h){
								printf("g is max");
							}
							    else{
								printf("h is max");
							}
							}	
					}
					else{
						if(f>g){
							if(f>h){
								printf("f is max");
							}
							else{
								printf("h is max");
							}
						}
						else{
							if(g>h){
								printf("g is max");
							}
							else{
								printf("h is max");
							}
						}
					}
				}
			}
		}
		
	}
	
}
