#include<stdio.h>
main(){
	int i , j;
	
	printf("Enter Of Value Starting Programe : ");
	scanf("%d",&i);
	printf("Enter Of Value Ending Programe : ");
	scanf("%d",&j);
	
	do{
		if(j % 4 == 0){
			printf("%d",j);
		}
		j++;
		printf("\n");
	}while(j <= i);
}
