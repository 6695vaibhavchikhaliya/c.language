#include<stdio.h>
main(){
	int i = 10 , j;
	
	printf("Enter Of Value Starting Programe : ");
	scanf("%d",&i);
	printf("Enter Of Value Ending Programe : ");
	scanf("%d",&j);
	
	for(j=10;j<=i;j++){
		if(j % 4 == 1){
			printf("%d",j);
			printf("\n");
		}
	}
}
