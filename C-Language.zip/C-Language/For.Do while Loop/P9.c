#include<stdio.h>
main(){
	int i = 10 , j;
	
	printf("Enter Of Value Strating Programe : ");
	scanf("%d",&i);
	printf("Enter Of Value Ending Programe : ");
	scanf("%d",&j);
	
	for(j = 1;j <= i;j++){
		printf("%d",j);
		printf("\n");
	}
}
