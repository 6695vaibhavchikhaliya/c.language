#include<stdio.h>
main(){
	int i = 10 , j;
	
	for(j=1;j<=i;j++){
		printf("%d",j);
		printf("\n");
	}
} 
