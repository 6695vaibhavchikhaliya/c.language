#include<stdio.h>
main(){
	int i = 15 , j;
	
	printf("Enter Of Value Starting Programe : ");
	scanf("%d",&i);
	printf("Enter Of Value Ending Programe : ");
	scanf("%d",&j);
	
	for(i=15;i>=j;i--){
		if(i % 2 == 1){
			printf("%d",i);
		}
		printf("\n");
	}
}
