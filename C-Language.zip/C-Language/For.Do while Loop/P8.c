#include<stdio.h>
main(){
	int i = 10 , j;
	
	for(i=10;i>=j;i--){
		printf("%d",i);
		printf("\n");
	}
}
