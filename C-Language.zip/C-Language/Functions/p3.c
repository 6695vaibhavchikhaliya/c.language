#include<stdio.h>

int add();

int main(){
	int a;
	a = add();
	printf("%d",a);
}

int add(){
	int a , b;
	printf("Enter Of Number A : ");
	scanf("%d",&a);
	printf("Enter Of Number B : ");
	scanf("%d",&b);
	
	return a + b;
}
