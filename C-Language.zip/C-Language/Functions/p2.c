#include<stdio.h>
main(){
	int ans = sum(10,20);
	printf("Ans Is %d",ans);
	return 0;
	
}

int sum(int a,int b){
	int SUM = a + b;
	return SUM;
}
