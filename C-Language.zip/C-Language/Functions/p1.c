#include<stdio.h>
main(){

	xyz();
	xyz();
	xyz();
	xyz();
	xyz();

}

void xyz(){
	printf("Vaibhav Chikhaliya..!");
}
