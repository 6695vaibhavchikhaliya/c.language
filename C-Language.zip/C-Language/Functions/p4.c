#include<stdio.h>

int add(int,int)

int main(){
	int a , b;
	printf("Enter Of Number A : ");
	scanf("%d",&a);
	printf("Enter Of Number B : ");
	scanf("%d",&b);
	a = add(a , b);
	printf("%d",a);
	return 0;
}

int add(int x , int y){
	return x + y;
}
