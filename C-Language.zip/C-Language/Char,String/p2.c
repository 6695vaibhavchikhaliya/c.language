#include<stdio.h>
main(){
	
	char str[] = "Hello";
	
	printf("%s",strupr(str));
}
