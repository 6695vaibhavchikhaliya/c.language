#include<stdio.h>
main(){
	
	char str[] = "Hello";
	
	int length = strlen(str);
	
	printf("%d",length);
}
