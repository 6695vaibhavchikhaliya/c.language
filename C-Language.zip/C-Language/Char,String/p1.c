#include<stdio.h>
main(){
	char i;
	
	for(i=65;i<=90;i++){
		printf("%c",i);
	}
}
