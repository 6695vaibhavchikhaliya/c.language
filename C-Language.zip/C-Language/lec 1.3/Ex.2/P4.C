#include<stdio.h>

main(){
	
	int a,b;
	
	printf("Enter Your First Number Of A : \n");
	scanf("%d",&a);
	printf("Enter Your Second Number Of B : \n");
	scanf("%d",&b);
	
	printf("%d / %d = %d",a,b,a / b);
}
